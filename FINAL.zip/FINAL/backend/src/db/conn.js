const mongoose =require("mongoose"); 
mongoose.connect("mongodb://localhost:27017/Automation_Automation",{
   
}).then(()=>{
    console.log('SUCCESS');
}).catch((e)=>{
  console.log(e);
})